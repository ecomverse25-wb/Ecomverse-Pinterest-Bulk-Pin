# Ecomverse Pinterest Bulk Pin Generator

This is a React application built with Vite and Google Gemini API.

## Deployment on Hostinger

1. Ensure the repository is connected to Hostinger via Git.
2. Select **Vite** or **React** as the framework.
3. Build Command: `npm run build`
4. Output Directory: `dist`