
// Step 1: Deploy the license_server_example.js to a hosting provider (Render, Vercel, Heroku, etc.)
// Step 2: Paste the URL of your deployed server here.
// Example: https://my-pinterest-app-backend.onrender.com
export const APP_CONFIG = {
    LICENSE_API_URL: 'http://localhost:3000/verify-license', // Change this to your live server URL
};
